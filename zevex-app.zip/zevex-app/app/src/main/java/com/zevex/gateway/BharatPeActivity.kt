package com.zevex.gateway

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import android.widget.Button
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/**
 * Merchant yahan apne BharatPe account se khud login karta hai (asli BharatPe page, uske apne phone aur IP se).
 * Login ke baad portal ka apna TOKEN aur Merchant ID padh ke Zevex ke page ko bhej diya jata hai.
 * Is screen par sirf *.bharatpe.in khulta hai. Kaam hone par BharatPe ki cookies/storage saaf ho jati hain.
 */
class BharatPeActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private var done = false
    private var attempt = 0

    private val loginHost = "enterprise.bharatpe.in"

    private val extractJs = """
        (async function () {
          try {
            var t = window.localStorage.getItem('TOKEN') || '';
            var m = [];
            if (t) {
              try {
                var r = await (await fetch('/v1/api/brandMerchants', {
                  credentials: 'same-origin',
                  headers: {'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json'}
                })).json();
                m = (r.data || [])
                  .filter(function (x) { return x && x.id && String(x.id) !== '0'; })
                  .map(function (x) { return {id: String(x.id), name: String(x.business_name || '')}; });
              } catch (e) {}
            }
            ZevexBridge.onToken(t, JSON.stringify(m));
          } catch (e) {
            ZevexBridge.onToken('', '[]');
          }
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bharatpe)

        web = findViewById(R.id.web)
        progress = findViewById(R.id.progress)
        findViewById<Button>(R.id.cancel).setOnClickListener { cancel() }

        clearBharatPeCookies() // hamesha fresh login

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true) // BharatPe ke security check ke liye

        // Android WebView apne aap "X-Requested-With" header bhejta hai jisse site ko pata chal jata hai ki
        // request kisi app ke andar se hai, browser se nahi. Kuch firewalls isi wajah se block kar dete hain.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderMode(
                s, WebSettingsCompat.REQUESTED_WITH_HEADER_MODE_NO_HEADER
            )
        }

        web.addJavascriptInterface(Bridge(), "ZevexBridge")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val h = request?.url?.host ?: return true
                return !(h == "bharatpe.in" || h.endsWith(".bharatpe.in"))
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                val u = Uri.parse(url ?: "")
                val path = u.path ?: ""
                // login page ke baad ke kisi bhi page par token dhundo
                if (u.host == loginHost && path != "" && path != "/" && !path.startsWith("/login")) {
                    attempt = 0
                    handler.postDelayed({ extract() }, 1500)
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else cancel()
            }
        })

        web.loadUrl("https://$loginHost/")
    }

    private fun extract() {
        if (done) return
        web.evaluateJavascript(extractJs, null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun onToken(token: String?, merchants: String?) {
            runOnUiThread { handleToken(token ?: "", merchants ?: "[]") }
        }
    }

    private fun handleToken(token: String, merchants: String) {
        if (done) return
        // sirf BharatPe ke apne page se aaya hua token maana jaye
        if ((Uri.parse(web.url ?: "").host ?: "") != loginHost) return
        if (token.isEmpty()) {
            if (attempt < 4) {
                attempt++
                handler.postDelayed({ extract() }, 1500)
            }
            return
        }
        done = true
        web.evaluateJavascript("try{localStorage.clear();sessionStorage.clear();}catch(e){}", null)
        clearBharatPeCookies()
        setResult(
            RESULT_OK,
            Intent().putExtra("token", token).putExtra("merchants", merchants)
        )
        handler.postDelayed({ finish() }, 200)
    }

    private fun cancel() {
        done = true
        clearBharatPeCookies()
        setResult(RESULT_CANCELED)
        finish()
    }

    private fun clearBharatPeCookies() {
        val cm = CookieManager.getInstance()
        for (u in listOf("https://enterprise.bharatpe.in", "https://bharatpe.in")) {
            val c = cm.getCookie(u) ?: continue
            for (kv in c.split(";")) {
                val name = kv.substringBefore("=").trim()
                if (name.isNotEmpty()) {
                    cm.setCookie(u, "$name=; Max-Age=0; Path=/")
                    cm.setCookie(u, "$name=; Max-Age=0; Path=/; Domain=bharatpe.in")
                }
            }
        }
        cm.flush()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }
}
