package com.zevex.gateway

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Merchant yahan apne Google Pay Business account se khud login karta hai (asli pay.google.com page,
 * uske apne phone aur IP se). Login ke baad merchant "Session capture karein" dabata hai, jisse
 * is page ki cookie aur session token nikal ke seedha Zevex ke /api/googlepay/save par bheja jata hai
 * (wahi public endpoint jo companion-app APK flow ke liye pehle se bana hua hai).
 */
class GooglePayActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private lateinit var captureBar: LinearLayout
    private var done = false

    private val host = "pay.google.com"
    private val apiHost: String by lazy { Uri.parse(BuildConfig.BASE_URL).host ?: "zevex.in" }

    private val tokenJs = """
        (function () {
          try {
            var at = '';
            var pats = [/"at":"([^"]{8,80})"/, /\bat=([A-Za-z0-9_\-\.]{8,80})\b/];
            var pools = [];
            try { for (var i = 0; i < localStorage.length; i++) { pools.push(localStorage.getItem(localStorage.key(i)) || ''); } } catch (e) {}
            try { for (var j = 0; j < sessionStorage.length; j++) { pools.push(sessionStorage.getItem(sessionStorage.key(j)) || ''); } } catch (e) {}
            pools.push(document.documentElement ? document.documentElement.innerHTML : '');
            for (var k = 0; k < pools.length && !at; k++) {
              for (var p = 0; p < pats.length && !at; p++) {
                var m = pats[p].exec(pools[k]);
                if (m) at = m[1];
              }
            }
            return at;
          } catch (e) { return ''; }
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_googlepay)

        web = findViewById(R.id.web)
        progress = findViewById(R.id.progress)
        captureBar = findViewById(R.id.captureBar)
        findViewById<Button>(R.id.cancel).setOnClickListener { cancel() }
        findViewById<Button>(R.id.captureBtn).setOnClickListener { capture() }

        clearGpCookies() // hamesha fresh login

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true) // Google ke login/security check ke liye

        // Android WebView apne aap "X-Requested-With" header bhejta hai jisse site ko pata chal jata hai ki
        // request kisi app ke andar se hai, browser se nahi. Kuch firewalls isi wajah se block kar dete hain.
        // Khali allow-list dene se ye header kisi bhi origin ko nahi jaata.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(s, emptySet())
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val h = request?.url?.host ?: return true
                return !(h == "google.com" || h.endsWith(".google.com"))
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                val u = Uri.parse(url ?: "")
                val path = u.path ?: ""
                captureBar.visibility =
                    if (u.host == host && path.startsWith("/g4b/") && !path.contains("signin") && !path.contains("login")) View.VISIBLE
                    else View.GONE
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else cancel()
            }
        })

        val given = intent.getStringExtra("mobile")?.filter { it.isDigit() }?.takeLast(10) ?: ""
        if (given.length == 10) {
            mobileNumber = given
            web.loadUrl("https://$host/g4b/")
        } else {
            askMobileThenStart()
        }
    }

    private var mobileNumber: String = ""

    private fun askMobileThenStart() {
        val input = EditText(this)
        input.hint = "Google Pay registered mobile (10 digit)"
        input.inputType = InputType.TYPE_CLASS_PHONE
        val pad = (16 * resources.displayMetrics.density).toInt()
        input.setPadding(pad, pad, pad, 0)
        AlertDialog.Builder(this)
            .setTitle("Mobile number")
            .setMessage("Wahi mobile number daalein jo site par daala hai.")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Aage badhein") { _, _ ->
                val m = input.text.toString().filter { it.isDigit() }.takeLast(10)
                if (m.length != 10) {
                    Toast.makeText(this, "Sahi 10 digit mobile number daalein.", Toast.LENGTH_LONG).show()
                    askMobileThenStart()
                } else {
                    mobileNumber = m
                    web.loadUrl("https://$host/g4b/")
                }
            }
            .setNegativeButton("Cancel") { _, _ -> cancel() }
            .show()
    }

    private fun capture() {
        if (done) return
        web.evaluateJavascript(tokenJs) { raw ->
            val at = try {
                (JSONTokener(raw).nextValue() as? String) ?: ""
            } catch (e: Exception) { "" }
            val cookie = CookieManager.getInstance().getCookie("https://$host") ?: ""
            if (at.isEmpty() || cookie.isEmpty()) {
                Toast.makeText(this, "Session nahi mila. Login poora karke dobara try karein.", Toast.LENGTH_LONG).show()
                return@evaluateJavascript
            }
            val mid = guessMid()
            if (mid.isNotEmpty()) {
                submit(at, cookie, mid, mobileNumber) // mobile pehle se mil chuka hai, sab kuch yahin se automatic
            } else {
                promptMid(at, cookie)
            }
        }
    }

    private fun guessMid(): String {
        val path = web.url?.let { Uri.parse(it).pathSegments } ?: return ""
        val i = path.indexOf("transactions")
        return if (i >= 0 && i + 1 < path.size && path[i + 1].all { it.isDigit() }) path[i + 1] else ""
    }

    private fun promptMid(at: String, cookie: String) {
        val mid = EditText(this)
        mid.hint = "Google Pay Merchant ID"
        val pad = (16 * resources.displayMetrics.density).toInt()
        mid.setPadding(pad, pad, pad, 0)
        AlertDialog.Builder(this)
            .setTitle("Merchant ID")
            .setMessage("Ye apne aap nahi mila. Google Pay Business console me se daal dein.")
            .setView(mid)
            .setPositiveButton("Connect karein") { _, _ ->
                val mi = mid.text.toString().trim()
                if (mi.isEmpty()) {
                    Toast.makeText(this, "Merchant ID daalein.", Toast.LENGTH_LONG).show()
                } else {
                    submit(at, cookie, mi, mobileNumber)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun submit(at: String, cookie: String, mid: String, mobile: String) {
        Thread {
            var ok = false
            var msg = "Network error"
            try {
                val body = JSONObject()
                body.put("auth_token", at)
                body.put("cookie", cookie)
                body.put("mid", mid)
                body.put("profile_name", mobile)

                val conn = URL("https://$apiHost/api/googlepay/save").openConnection() as HttpsURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.connectTimeout = 10000
                conn.readTimeout = 15000
                conn.setRequestProperty("Content-Type", "application/json")
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
                val res = try { JSONObject(text) } catch (e: Exception) { JSONObject() }
                ok = res.optBoolean("status", false)
                msg = res.optString("message", if (ok) "Session saved" else "Save nahi ho paya")
            } catch (e: Exception) {
                msg = "Network error. Dobara try karein."
            }
            val finalOk = ok
            val finalMsg = msg
            runOnUiThread { finish(finalOk, finalMsg, mobile) }
        }.start()
    }

    private fun finish(ok: Boolean, msg: String, mobile: String) {
        if (!ok) {
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            return
        }
        done = true
        web.evaluateJavascript("try{localStorage.clear();sessionStorage.clear();}catch(e){}", null)
        clearGpCookies()
        val data = Intent()
        data.putExtra("mobile", mobile)
        setResult(RESULT_OK, data)
        finish()
    }

    private fun cancel() {
        done = true
        clearGpCookies()
        setResult(RESULT_CANCELED)
        finish()
    }

    private fun clearGpCookies() {
        val cm = CookieManager.getInstance()
        for (u in listOf("https://$host", "https://google.com", "https://accounts.google.com")) {
            val c = cm.getCookie(u) ?: continue
            for (kv in c.split(";")) {
                val name = kv.substringBefore("=").trim()
                if (name.isNotEmpty()) {
                    cm.setCookie(u, "$name=; Max-Age=0; Path=/")
                    cm.setCookie(u, "$name=; Max-Age=0; Path=/; Domain=google.com")
                }
            }
        }
        cm.flush()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
